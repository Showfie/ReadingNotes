/**
 * Created by Chase on 16/10/20.
 */

package com.example.yuchaoqun.helloworldjni;

public class JNIuseUtil {
    static {
        System.loadLibrary("MyJniLibName");
    }
    public static native String getStringFromC();
}